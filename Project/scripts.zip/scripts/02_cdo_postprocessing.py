import os
import os.path as op
# Directorio con los archivos de entrada
# input_dir = 'C:\\Users\\aag23\\Documents\\9ec61f3d95be7870bb9f9cda2e68d28e'
input_dir = '/mnt/c/Users/aag23/Documents/9ec61f3d95be7870bb9f9cda2e68d28e'
# Hacemos un listado de los archivos en el directorio
import os
input_files = os.listdir(input_dir)
# vemos que son ficheros con extensión .grib y los pasamos a formato .nc con cdo
input_files = [f for f in input_files if f.endswith('.grib')]
# Creamos un directorio de salida
# output_dir = 'C:\\Users\\aag23\\Documents\\9ec61f3d95be7870bb9f9cda2e68d28e\\output'
output_dir = '/mnt/c/Users/aag23/Documents/9ec61f3d95be7870bb9f9cda2e68d28e/output'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
# Procesamos los ficheros
for f in input_files:
    input_file = op.join(input_dir, f)
    output_file = op.join(output_dir, f.replace('.grib', '.nc'))
    cmd = 'cdo -f nc copy ' + input_file + ' ' + output_file
    os.system(cmd)